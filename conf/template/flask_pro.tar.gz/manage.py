# encoding: utf-8
__author__ = "Vladimir Roncevic"
__copyright__ = "Copyright 2017, Free software to use and distributed it."
__credits__ = ["Vladimir Roncevic"]
__license__ = "GNU General Public License (GPL)"
__version__ = "1.0.0"
__maintainer__ = "Vladimir Roncevic"
__email__ = "elektron.ronca@gmail.com"
__status__ = "Updated"

# python manage.py create_db
# python manage.py db init
# python manage.py db migrate
# python manage.py create_admin
# python manage.py create_data
# python manage.py runserver

import os
import unittest
import coverage
from flask_script import Manager
from flask_migrate import Migrate, MigrateCommand

COV = coverage.coverage(
	branch=True,
	include='project/*',
	omit=[
		'project/tests/*',
		'project/server/config.py',
		'project/server/*/__init__.py'
	]
)

COV.start()

from project.server import app, db
from project.server.models import User

migrate = Migrate(app, db)
manager = Manager(app)
manager.add_command('db', MigrateCommand)

@manager.command
def test():
	tests = unittest.TestLoader().discover('project/tests', pattern='test*.py')
	result = unittest.TextTestRunner(verbosity=2).run(tests)
	if result.wasSuccessful():
		return 0
	return 1

@manager.command
def cov():
	tests = unittest.TestLoader().discover('project/tests')
	result = unittest.TextTestRunner(verbosity=2).run(tests)
	if result.wasSuccessful():
		COV.stop()
		COV.save()
		print('Coverage Summary:')
		COV.report()
		basedir = os.path.abspath(os.path.dirname(__file__))
		covdir = os.path.join(basedir, 'tmp/coverage')
		COV.html_report(directory=covdir)
		print('HTML version: file://%s/index.html' % covdir)
		COV.erase()
		return 0
	return 1

@manager.command
def create_db():
	db.create_all()

@manager.command
def drop_db():
	db.drop_all()

@manager.command
def create_admin():
	db.session.add(User(email='admin@admin.com', password='admin', admin=True))
	db.session.commit()

@manager.command
def create_data():
	pass

if __name__ == '__main__':
	manager.run()


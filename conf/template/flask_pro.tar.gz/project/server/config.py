# encoding: utf-8
__author__ = "Vladimir Roncevic"
__copyright__ = "Copyright 2017, Free software to use and distributed it."
__credits__ = ["Vladimir Roncevic"]
__license__ = "GNU General Public License (GPL)"
__version__ = "1.0.0"
__maintainer__ = "Vladimir Roncevic"
__email__ = "elektron.ronca@gmail.com"
__status__ = "Updated"

import os
basedir = os.path.abspath(os.path.dirname(__file__))

class BaseConfig(object):
	SECRET_KEY = 'my_precious'
	DEBUG = False
	BCRYPT_LOG_ROUNDS = 13
	WTF_CSRF_ENABLED = True
	DEBUG_TB_ENABLED = False
	DEBUG_TB_INTERCEPT_REDIRECTS = False
	SQLALCHEMY_TRACK_MODIFICATIONS = False

class DevelopmentConfig(BaseConfig):
	DEBUG = True
	BCRYPT_LOG_ROUNDS = 4
	WTF_CSRF_ENABLED = False
	SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'dev.sqlite')
	DEBUG_TB_ENABLED = True

class TestingConfig(BaseConfig):
	DEBUG = True
	TESTING = True
	BCRYPT_LOG_ROUNDS = 4
	WTF_CSRF_ENABLED = False
	SQLALCHEMY_DATABASE_URI = 'sqlite:///'
	DEBUG_TB_ENABLED = False
	PRESERVE_CONTEXT_ON_EXCEPTION = False

class ProductionConfig(BaseConfig):
	SECRET_KEY = 'my_precious'
	DEBUG = False
	SQLALCHEMY_DATABASE_URI = 'postgresql://localhost/example'
	DEBUG_TB_ENABLED = False


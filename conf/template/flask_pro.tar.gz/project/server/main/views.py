# encoding: utf-8
__author__ = "Vladimir Roncevic"
__copyright__ = "Copyright 2017, Free software to use and distributed it."
__credits__ = ["Vladimir Roncevic"]
__license__ = "GNU General Public License (GPL)"
__version__ = "1.0.0"
__maintainer__ = "Vladimir Roncevic"
__email__ = "elektron.ronca@gmail.com"
__status__ = "Updated"

from flask import render_template, Blueprint

main_blueprint = Blueprint('main', __name__,)

@main_blueprint.route('/')
def home():
	return render_template('main/home.html')

@main_blueprint.route("/about/")
def about():
	return render_template("main/about.html")

